Hi LSEG Team , Thanks for giving me this oppertunity to solve this challange.

Please review below for the go trough of my script:

In the zip file we will have challange.py, this readme file, and the folder which have csv files provided with this challange

Here I have used pandas, so before executing this script please install pandas using "pip install pandas"

Below are the modules I have used in my script, plesae install what ever missing module from your end using above command.
pandas
pandas as pd
random
getopt
sys
os
glob

Here I have used below functions:
getArgs() - to take the input from the end user
prevalidate() - to perform validations such as - whether the given path exists or not, do we have csv files exists or not, file should have more than 31 lines etc
extract_consecutive_data() - This function to read file and extract 30 consecutive data points from a random timestamp
identify_outliers_and_save - This function to identify outliers and save results to CSV

Here are some execution outputs:

>>> If you don't give any values to the parameters:

PS C:\LSEG project> python ./Challange.py
Error: Input is not correct

   usage :  ./Challange.py --DirPath=<path of the file> --NumberOfFiles=<enter number of files to process>

   Example: ./Challange.py --DirPath='C:/LSEG Project' --NumberOfFiles=2
  

>>> Here I have many csv files (8) , I have given the number of files as 3. So it processed for 3 files, in that one file I have created emtpy csv and it removed it.

PS C:\LSEG project> python ./Challange.py --DirPath='C:\LSEG project' --NumberOfFiles=3
Directory found, proceeding for more validations
csv files found
file should contain at least 31 rows including hearder
105
['FLTR LSE.csv', 'GSK LSE.csv']
PS C:\LSEG project>

>>> Here I have given the correct path where we don't have csv files:
PS C:\Users\91905\OneDrive\Desktop\LSEG project> python ./perfectscript.py --DirPath='C:\Users\91905\OneDrive\Desktop\' --NumberOfFiles=3
Directory found, proceeding for more validations
csv files not found cannot proceed
PS C:\Users\91905\OneDrive\Desktop\LSEG project>

>>> Here I have given the path which is not exists:
PS C:\LSEG project> python ./Challange.py --DirPath='C:\abc' --NumberOfFiles=3                          
Entered directory not found
PS C:\LSEG project> 

>>> If you give perfect location where we have csv files. I have given number of files as 3, but directory has only 2, so processing for 2 files. outlier files will be gets created in same directory.

PS C:\LSEG project> python ./Challage.py --DirPath='C:\LSEG project\LSE' --NumberOfFiles=3
Directory found, proceeding for more validations
csv files found
['FLTR LSE.csv', 'GSK LSE.csv']
outliers file got created for FLTR LSE.csv
outliers file got created for GSK LSE.csv
PS C:\LSEG project>

This script will identify and remove the outlier files created in same folder for next execution.
PS C:\Users\91905\OneDrive\Desktop\LSEG project> python .\Challange.py --DirPath='C:\Users\91905\OneDrive\Desktop\LSEG project\LSE' --NumberOfFiles=6
Directory found, proceeding for more validations
csv files found
outlier file found and removed from list FLTR LSE.csv_outliers.csv
outlier file found and removed from list GSK LSE.csv_outliers.csv
['FLTR LSE.csv', 'GSK LSE.csv']
['FLTR LSE.csv', 'GSK LSE.csv']
outliers file got created for FLTR LSE.csv
outliers file got created for GSK LSE.csv
PS C:\Users\91905\OneDrive\Desktop\LSEG project> 


I have added 2 outlier files which got created : GSK LSE.csv_outliers, FLTR LSE.csv_outliers

