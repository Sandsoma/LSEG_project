import pandas
import pandas as pd
import random
import getopt
import sys
import os
import glob

# Function to get the user input
def getArgs():

    dict = {}
    dict['DirPath'] = ''
    dict['NumberOfFiles'] = ''
    
    try:
        options, remainder = getopt.getopt(sys.argv[1:], 'hv', ['DirPath=', 'NumberOfFiles='])
        for opt, arg in options:
            if opt == '--DirPath':
                dict['DirPath'] = arg
            if opt == '--NumberOfFiles':
                dict['NumberOfFiles'] = arg

        if dict['DirPath'] == '' or dict['NumberOfFiles'] == '':
            sys.exit(1)
        
        return dict
    
    except:
        print ("Error: Input is not correct")
        print ("\n   usage :  {0} --DirPath=<path of the file> --NumberOfFiles=<enter number of files to process>".format(sys.argv[0]))
        print ("\n   Example: {0} --DirPath='C:/LSEG Project' --NumberOfFiles=2".format(sys.argv[0]))
        sys.exit(1)

def prevalidate(data):
    dir_path = data['DirPath']
    files_to_process = int(data['NumberOfFiles'])
    file_names = ''
    csvfiles = ''
    # Check if the entered path exists or not
    if os.path.exists(dir_path):
        print("Directory found, proceeding for more validations")
        os.chdir(dir_path)
        listoffiles = glob.glob("*.csv")
        csvfiles = len(listoffiles)
        if len(listoffiles) > 0:
            print("csv files found")
            if csvfiles > files_to_process:
                file_names = listoffiles[:files_to_process]           
            else:
                file_names =  listoffiles 
            for file in file_names:
                if '_outliers' in file:
                    print ("outlier file found and removed from list {0}".format(file))
                    file_names.remove(file) 
            print (file_names)
            for file_name in file_names:
                try:
                    df = pd.read_csv(file_name)
                    num_rows = len(df)
                    #print(num_rows) 
                    if num_rows < 31:
                        print("file should contain at least 31 rows including hearder")
                except pandas.errors.EmptyDataError:
                    print("file should contain at least 31 rows including hearder")
                    file_names.remove(file_name)
            return file_names
                        
        else:
            print("csv files not found cannot proceed")
            sys.exit(1)

    else:
        print("Entered directory not found")
        sys.exit(1) 

    # Check the number of rows, callout if its less than 31
    #try:
    #    df = pd.read_csv(file_name)
    #    num_rows = len(df)
    #    print(num_rows)
    #    if num_rows < 31:
#
    #        print("file should contain at least 31 rows including hearder")
    #        sys.exit()
    #except pandas.errors.EmptyDataError:
    #    print("file should contain at least 31 rows including hearder")
    #    sys.exit()

# Function to read file and extract 30 consecutive data points from a random timestamp
def extract_consecutive_data(file_path):
    df = pd.read_csv(file_path)  # Assuming the file is in CSV format
    title = ['Group', 'Time stamp', 'Stock Price']
    df.to_csv("file_path", header=title, index=False)
    file2 = pd.read_csv("file_path")
    #print (file2)
    num_rows = len(file2)
    start_index = random.randint(0, num_rows - 31)  # Select a random starting index

    # Select 30 consecutive data points
    selected_data = file2.iloc[start_index:start_index + 31]
    return selected_data

# Function to identify outliers and save results to CSV
def identify_outliers_and_save(selected_data, file_name, threshold=0.05):
    # Calculate mean
    mean_value = selected_data['Stock Price'].mean()

    # Calculate deviation and percentage deviation
    selected_data['Deviation'] = selected_data['Stock Price'] - mean_value
    selected_data['Percentage Deviation'] = (selected_data['Deviation'] / mean_value) * 100

    # Identify outliers
    outliers = selected_data[abs(selected_data['Percentage Deviation']) > threshold]

    # Save outliers to CSV
    outliers.to_csv(f"{file_name}_outliers.csv", index=False)
    print("outliers file got created for {0}".format(file_name))

# defining main method
def main():
    data = {}
    #FilePath = ''
    data = getArgs()
    data['file_names'] = prevalidate(data)
    print(data['file_names'])
    for file in data['file_names']:
        randomdata = extract_consecutive_data(file)
        identify_outliers_and_save(randomdata, file)

if __name__ == "__main__":
    main()